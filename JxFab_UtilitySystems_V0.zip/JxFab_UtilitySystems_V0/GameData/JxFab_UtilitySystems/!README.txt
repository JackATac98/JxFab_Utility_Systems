______/\\\\\\\\\\\________________/\\\\\\\\\\\\\\\_________________/\\\________        
 _____\/////\\\///________________\/\\\///////////_________________\/\\\________       
  _________\/\\\___________________\/\\\____________________________\/\\\________      
   _________\/\\\______/\\\____/\\\_\/\\\\\\\\\\\______/\\\\\\\\\____\/\\\________     
    _________\/\\\_____\///\\\/\\\/__\/\\\///////______\////////\\\___\/\\\\\\\\\__    
     _________\/\\\_______\///\\\/____\/\\\_______________/\\\\\\\\\\__\/\\\////\\\_   
      __/\\\___\/\\\________/\\\/\\\___\/\\\______________/\\\/////\\\__\/\\\__\/\\\_  
       _\//\\\\\\\\\_______/\\\/\///\\\_\/\\\_____________\//\\\\\\\\/\\_\/\\\\\\\\\__ 
        __\/////////_______\///____\///__\///_______________\////////\//__\/////////___
JxFab Utility Systems V0
Hi :)

This is my first part and it should be the first of many.
To Leave any feedback, go visit my youtube channel and leave a comment!
https://www.youtube.com/c/JackOfNothing
https://www.patreon.com/JackATac

ABOUT:
This mod aims to add on to the robotics section of the Breaking Ground DLC.
This mod REQUIRES the Breaking Ground DLC.
Currently in this mod is only a rail system with lengths of 5, 10, 15, and 30 meters.
Each part has three variants you can choose from.
Though this is a single part it has many possible uses.
You could create gantry cranes, elevators, railguns, amusement park rides, 
and possibly a device to be used for Kraken summoning.

INSTALLATION
Place the contents of GameData/ into your KSP/GameData/ directory. 

DEPENDENCIES
This pack REQUIRES the Breaking Ground DLC.

CHANGELOG
V0 - FIRST PUBLIC RELEASE
	- Added Straight Rail 5,10,15,30 meter parts

ROADMAP
- May add a 2.5m and a 7.5m version of the straight rail if I get enough feedback. 
- Will get around to converting the png textures to dds. Currently the gimp addon to do that corrupts the texture for some reason.
- Ill try to release a version of the pack that uses Infernal Robotics instead of the DLC. Currently it bugs out and variants dont work right because of the way IR references the base mesh i think. Also, nodes of the base mesh move with the servo even though specified not to.
- I have plans for a curved rail system, if you have suggestions on how you think I should exectute it please contact me.
- Plans for adding larger rotor type connection intended for centrifugal/artificial gravity station hubs.
- May try to make my own strut.
- Will continue working on my JxFab Orbital Systems modpack. It will contain no dependencies unlike this pack.
- Rescue Jeb from surface of Jool..